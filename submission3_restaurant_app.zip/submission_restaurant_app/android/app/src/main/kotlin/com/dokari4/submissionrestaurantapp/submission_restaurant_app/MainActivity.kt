package com.dokari4.submissionrestaurantapp.submission_restaurant_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
